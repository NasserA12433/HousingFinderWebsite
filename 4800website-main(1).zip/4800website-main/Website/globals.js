//global variable, seen by both UI and WS code
var number;
