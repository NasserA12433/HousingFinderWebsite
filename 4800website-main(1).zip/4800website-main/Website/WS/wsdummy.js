
function getNumber() {
  //uses creates a popup for user input, saves it to the number var
  number = prompt("Enter a number");

  console.log(number) //prints the number to the debugging console
}
