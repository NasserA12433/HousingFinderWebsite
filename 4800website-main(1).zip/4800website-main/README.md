# 4800website
Cs4800 Project
#Housing website designed to assist students looking for places to live in a vicinity around Cal Poly Pomona.Cancel changes

Instructions:
-------------------------------
-- Website --

**Run the website by opening index.html file in the website folder with any browser**

Tips and Guidelines

Root directory is where the index.html file is.

Limit 1 JS file = 1 function for easier merging.

JS, CSS, and HTML are plain text file. Any editor will do.

If changes are not being shown, your browser maybe caching the old files. In that case do a hard refresh of the page

Some browsers filter out console.log(). If you don't see it try checking your filters.

You can run commands and edit variables directly from the debug console (chrome, safari, edge, firefox) Note: These wont be saved.


Teams:
-------------------------------
**UI->**

Kevin Kongwattnachai (PM)

Ryan Trinh (Developer)

Brandon Anaya (Developer)

Joshua Pao (Developer)

Solomon (Business, Q&A)

-------------------------------
**WebService->**

Nasser Alanabulsi (PM)

Phillip Che (Developer)

Samanyu Satheesh (Developer)

Luc

Carlos Rodriguez

--------------------------------
**BackEnd->**
